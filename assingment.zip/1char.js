let a="school"
let b=a.indexOf("o");
console.log(b);