let a=4;
let b=a*60;
console.log(b);