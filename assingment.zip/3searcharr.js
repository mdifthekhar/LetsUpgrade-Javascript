let a=["apple","orange","pine","grape"];
let b=a.indexOf("pine");
console.log(b);
