let a=["a","b","c","a"];
for(let i=0;i<=3;i++)
if(a[i]==='a')
console.log(a[i]);