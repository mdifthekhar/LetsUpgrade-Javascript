let data=["sai","naveen","harish","bunty"];
let b=data.reverse();
console.log(b);